#!/bin/bash

# Epam DevOps Online Lab
# Scripting: Bash. Exit task
# Home task 1

declare -A sets_email  #HASH for equals emails check
declare -a id_array
declare -a location_id_array
declare -a name_array
declare -a title_array
declare -a email_array
declare -a department_array

while IFS="," read -r id location_id name title email department
do
	id_array+=($id)     #add "id" to array, another columns are indexed by "id" in case of "id" column is unsorted 
	location_id_array[$id]=$location_id
	title_array[$id]=$title
	department_array[$id]=$department

	name="${name,,}"   #lowercase all letter of name
	IFS=' ' read -ra fname_array <<< "$name"  #split name 
	name_array[$id]="${fname_array[0]^} ${fname_array[1]^}"  #uppercase first letter of name/surname and split name

	est="${fname_array[0]:0:1}${fname_array[1]}" #make HASH key for email
	est="${est,,}"			#lowercase all lettetr of HASH's key
	if [[ -v sets_email["${est}"] ]]; then    #if same key exist flag it "more" 
		sets_email["${est}"]="more"
	else
		sets_email["${est}"]="first"
	fi
	email_array[$id]=$est 
done < <(tail -n +2 $1)   #Ignoring the Header Line

echo "id,location_id,name,title,email,department" > ./accounts_new.csv #add CSV header
for i in "${id_array[@]}"; 
do
	if [ ${sets_email[${email_array[$i]}]}  == "more" ]; then    #flag "more" means this email has equals. Add location_id. 
		email_array[$i]="${email_array[$i]}${location_id_array[$i]}"
	fi
	email_array[$i]="${email_array[$i]}@abc.com"   #add @abc.com to an email address.
	echo "$i,${location_id_array[$i]},${name_array[$i]},${title_array[$i]},${email_array[$i]},${department_array[$i]}" >> ./accounts_new.csv
done