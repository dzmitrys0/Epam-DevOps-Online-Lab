﻿Param (
    [string]$ip_address_1,
    [string]$ip_address_2,
    [string]$network_mask
)


#check if $network_mask is PrefixLength convert to subnet mask in octet notation
if ( $network_mask -match '^\d{1,2}$' ) {
    [int]$cidr = $network_mask
    [int]$shift = 64 - $cidr
    [System.Net.IPAddress]$converted_mask = 0

    if ($cidr -ne 0) {
        $converted_mask = [System.Net.IPAddress]::HostToNetworkOrder([int64]::MaxValue -shl $shift)
    }
    $network_mask = $converted_mask.ToString()
}

#validates parametrs
$parsed = New-Object system.net.ipaddress ""
if ( -not (([System.Net.IPAddress]::TryParse($ip_address_1,[ref]$parsed))`
      -and ([System.Net.IPAddress]::TryParse($ip_address_2,[ref]$parsed))`
      -and ([System.Net.IPAddress]::TryParse($network_mask,[ref]$parsed))) ) {
    return "Invalid parameters"
}

#conerts parametrs to IPAddress object
[System.Net.IPAddress]$ip1 =$ip_address_1
[System.Net.IPAddress]$ip2 =$ip_address_2
[System.Net.IPAddress]$mask =$network_mask

#generates subnet for each IP address and compares it  
if ( ($ip1.Address -band $mask.Address) -eq ($ip2.Address -band $mask.Address) ){
    Write-Host "yes"
}
else{
    Write-Host "no"
}