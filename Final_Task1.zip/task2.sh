#!/bin/bash

# Epam DevOps Online Lab
# Scripting: Bash. Exit task
# Home task 2

declare -a name_array
declare -a status_array
declare -a duration_array
DIGIT="^[0-9]"

read test_name < $1
test_name=${test_name:2}
test_name=${test_name% ]* [0-9]*}

while read st || [[ -n "${st}" ]];
do
	#check the start of line and proccess only "ok", "not ok" and a digital
	if [ ${st:0:2} == "ok" ]; then   
		name=${st:7}
		name=${name%,*}
		status="true"
		duration=${st##*, }
	elif [ ${st:0:2} == "no" ]; then
		name=${st:11}
		name=${name%,*}
		status="false"
		duration=${st##*, }
	elif [[ $st =~ $DIGIT ]]; then
		total_succssess=$(echo $st | grep -oP "^\d*")
		total_failed=$(echo $st | grep -oP "\d* tests failed" | grep -oP "\d*")
		total_rating=$(echo $st | grep -oP "rated as (\d*.\d*|\d*)" | grep -oP "[\d.]*")
		total_duration=$(echo $st | grep -oP "spent \d*" | grep -oP "\d*")
		continue
	else
		continue
	fi
	name_array+=("$name")
	status_array+=("$status")
	duration_array+=("$duration")
done < $1

let last_array_i=${#name_array[*]}-1
echo "{" > ./output.json
echo " \"testName\":\"${test_name}\"," >> ./output.json
echo " \"tests\":[" >> ./output.json
for  i in ${!name_array[*]}
do
	echo "  {" >> ./output.json
	echo "   \"name\": \"${name_array[i]}\"," >> ./output.json
	echo "   \"status\": ${status_array[i]}," >> ./output.json
	echo "   \"duration\": \"${duration_array[i]}\"" >> ./output.json
	if [ $i == $last_array_i ]; then 
		echo "  }" >> ./output.json
	else
		echo "  }," >> ./output.json
	fi
done
echo " ]," >> ./output.json
echo " \"summary\":{" >> ./output.json
echo "  \"success\":${total_succssess}," >> ./output.json
echo "  \"failed\":${total_failed}," >> ./output.json
echo "  \"rating\":${total_rating}," >> ./output.json
echo "  \"duration\":\"${total_duration}ms\"" >> ./output.json
echo " }," >> ./output.json
echo "}," >> ./output.json
