﻿Param ([string]$file)

$accounts=Import-Csv -Path $file 
$set_emails = @{}

ForEach ($i in 0..($accounts.count-1) ){
    #create preparatory nic for email
    $name = $accounts[$i].name.split(' ')
    $accounts[$i].email = $name[0].ToLower()[0] + $name[1].ToLower()

    #if same nic already exist mark it 
    if ( $set_emails.ContainsKey($accounts[$i].email) ) {
        $set_emails[$accounts[$i].email] = $true
    }
    else {
        $set_emails[$accounts[$i].email] = $false
    } 
}

ForEach ($i in 0..($accounts.count-1) ){
    #fix name
    $accounts[$i].name = [cultureinfo]::GetCultureInfo("en-US").TextInfo.ToTitleCase($accounts[$i].name)
    #fix email
    if ( $set_emails[$accounts[$i].email] ) {
        $accounts[$i].email = $accounts[$i].email + $accounts[$i].location_id + '@abc.com'
    }
    else {
        $accounts[$i].email = $accounts[$i].email + '@abc.com'
    }    
}

#export to accounts_new.csv only 6 columns
$accounts | Select-Object -Property id,location_id,name,title,email,department | Export-Csv -UseQuotes AsNeeded -Path .\accounts_new.csv -NoTypeInformation